<template>
  <div class="polygons absolute h-full inset-0 z-0">
    <div class="polygon absolute top-1/4 left-8">
      <svg
        width="80"
        height="80"
        viewBox="0 0 194 194"
        class="animate-spin1"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M167.392 34.0469C193.793 41.1069 202.635 74.0424 183.309 93.3308L93.5154 182.947C74.1889 202.235 41.1882 193.41 34.1142 167.062L1.24751 44.6439C-5.8265 18.2955 18.3317 -5.81499 44.7322 1.24504L167.392 34.0469Z"
          class="polygon-path"
        />
      </svg>
    </div>

    <div class="polygon absolute top-18 left-56">
      <svg
        width="80"
        height="80"
        viewBox="0 0 194 194"
        class="animate-spin2"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M167.392 34.0469C193.793 41.1069 202.635 74.0424 183.309 93.3308L93.5154 182.947C74.1889 202.235 41.1882 193.41 34.1142 167.062L1.24751 44.6439C-5.8265 18.2955 18.3317 -5.81499 44.7322 1.24504L167.392 34.0469Z"
          class="polygon-path"
        />
      </svg>
    </div>

    <div class="polygon absolute -top-18 -right-48">
      <svg
        width="600"
        height="600"
        viewBox="0 0 194 194"
        fill="none"
        class="animate-spin3"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M167.392 34.0469C193.793 41.1069 202.635 74.0424 183.309 93.3308L93.5154 182.947C74.1889 202.235 41.1882 193.41 34.1142 167.062L1.24751 44.6439C-5.8265 18.2955 18.3317 -5.81499 44.7322 1.24504L167.392 34.0469Z"
          class="polygon-path"
        />
      </svg>
    </div>

    <div class="polygon absolute inset-64">
      <svg
        width="300"
        height="300"
        viewBox="0 0 194 194"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        class="animate-spin4"
      >
        <path
          d="M167.392 34.0469C193.793 41.1069 202.635 74.0424 183.309 93.3308L93.5154 182.947C74.1889 202.235 41.1882 193.41 34.1142 167.062L1.24751 44.6439C-5.8265 18.2955 18.3317 -5.81499 44.7322 1.24504L167.392 34.0469Z"
          class="polygon-path"
        />
      </svg>
    </div>
  </div>
</template>
