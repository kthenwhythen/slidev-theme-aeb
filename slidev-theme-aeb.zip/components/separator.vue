<template>
  <div class="separator"></div>
</template>
