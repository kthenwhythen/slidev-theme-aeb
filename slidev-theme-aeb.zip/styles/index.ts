// inherit from base layouts, remove it to get full customizations
import '@slidev/client/styles/layouts-base.css'
import './layout.css'
import './code.css'
